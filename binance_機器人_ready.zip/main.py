import os
import time
from binance.client import Client
from binance.enums import *
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

client = Client(API_KEY, API_SECRET)

SYMBOL = 'ETHUSDT'
LEVERAGE = 5
USDT_TO_TRADE = 100
PROFIT_TARGET = 10.0
CHECK_INTERVAL = 30

def set_leverage():
    try:
        client.futures_change_leverage(symbol=SYMBOL, leverage=LEVERAGE)
        print(f"[初始化] 槓桿設為 {LEVERAGE} 倍")
    except Exception as e:
        print("[錯誤] 設定槓桿失敗：", e)

def get_trade_quantity():
    price = float(client.futures_mark_price(symbol=SYMBOL)['markPrice'])
    quantity = round((USDT_TO_TRADE * LEVERAGE) / price, 3)
    return quantity

def has_position():
    pos = client.futures_position_information(symbol=SYMBOL)
    return abs(float(pos[0]['positionAmt'])) > 0

def get_profit():
    pos = client.futures_position_information(symbol=SYMBOL)
    return float(pos[0]['unrealizedProfit'])

def open_long():
    qty = get_trade_quantity()
    client.futures_create_order(
        symbol=SYMBOL,
        side=SIDE_BUY,
        type=ORDER_TYPE_MARKET,
        quantity=qty
    )
    print(f"[開多單] 數量：{qty}")
    return qty

def close_long(qty):
    client.futures_create_order(
        symbol=SYMBOL,
        side=SIDE_SELL,
        type=ORDER_TYPE_MARKET,
        quantity=qty
    )
    print(f"[平多單] 數量：{qty}")

def run():
    print("[機器人啟動] 開始自動交易...")
    qty = 0
    while True:
        try:
            if not has_position():
                print("[狀態] 無倉位 → 嘗試開倉")
                qty = open_long()
                time.sleep(5)
            else:
                profit = get_profit()
                print(f"[監控] 當前未實現利潤：{profit:.2f} USDT")
                if profit >= PROFIT_TARGET:
                    print("[動作] 達成停利 → 平倉中...")
                    close_long(qty)
                    time.sleep(5)
            time.sleep(CHECK_INTERVAL)
        except Exception as e:
            print("[錯誤] 程式執行錯誤：", e)
            time.sleep(60)

if __name__ == "__main__":
    set_leverage()
    run()